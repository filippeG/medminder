# Medminder

Medminder is a mobile-first medication tracking prototype for patients, carers, and family members. Patients can mark medication as taken, while carers can monitor adherence, add medicines, link accounts, and send reminder-style notifications.

## Features

- Patient and carer login prototype
- Link patient and carer accounts with a care-circle code
- Add medicines with dosage, notes, schedule, and exact dose times
- Mark doses as taken or missed
- Carer overview with taken, pending, and missed dose stats
- Phone-style popup notifications for reminders and updates
- English and Portuguese language toggle
- Mobile-first layout that also works on desktop

## Demo logins

```text
Patient: patient@medminder.app / 1234
Carer:   carer@medminder.app / 1234
```

## Important prototype note

This version stores demo accounts and medication changes in React state, so data resets when the page refreshes. For a real production version, connect the app to a persistent database such as Supabase, Firebase, or a custom backend.

## Tech stack

- React
- TypeScript
- Vite
- Tailwind CSS
- shadcn/ui components
- Express build template

## Run locally

Install dependencies:

```bash
npm install
```

Start the development server:

```bash
npm run dev
```

Build for production:

```bash
npm run build
```

Run the production build:

```bash
npm start
```

## Deploy to Vercel

The current deployed prototype is static. To deploy from this repository:

```bash
npm run build
npx vercel dist/public --prod
```

## Suggested next improvements

- Persistent account and medication storage
- Real authentication
- Real push notifications for iOS and Android
- Medicine edit/delete actions
- Carer invitations by email or SMS
- Accessibility and clinical safety review before real-world use
