import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

/**
 * Prototype scope: data lives in React state in the client.
 * The schema is defined for shared types between client and (future) server.
 * The legacy `users` table is retained so the template's storage layer stays compiled.
 */

export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// ---------------------------------------------------------------------------
// Medminder domain types (shared between client and any future API)
// ---------------------------------------------------------------------------

export const TIME_SLOTS = ["morning", "afternoon", "evening", "night"] as const;
export type TimeSlot = (typeof TIME_SLOTS)[number];

export const DOSE_STATUS = ["pending", "taken", "missed"] as const;
export type DoseStatus = (typeof DOSE_STATUS)[number];

export const medicationSchema = z.object({
  id: z.string(),
  name: z.string().min(1, "Name is required"),
  dosage: z.string().min(1, "Dosage is required"),
  schedule: z.array(z.enum(TIME_SLOTS)).min(1, "Pick at least one time"),
  times: z.record(z.string()).optional().default({}),
  notes: z.string().optional().default(""),
  color: z.string().optional().default("teal"),
  addedBy: z.enum(["carer", "patient"]).default("carer"),
});
export type Medication = z.infer<typeof medicationSchema>;

export const insertMedicationSchema = medicationSchema.omit({ id: true });
export type InsertMedication = z.infer<typeof insertMedicationSchema>;

export const doseLogSchema = z.object({
  id: z.string(),
  medicationId: z.string(),
  medicationName: z.string(),
  slot: z.enum(TIME_SLOTS),
  scheduledFor: z.string(), // ISO timestamp the dose was due
  status: z.enum(DOSE_STATUS),
  recordedAt: z.string(), // ISO timestamp the entry was logged
  takenAt: z.string().optional(), // ISO timestamp the patient confirmed
});
export type DoseLog = z.infer<typeof doseLogSchema>;

export const ACCOUNT_ROLES = ["patient", "carer"] as const;
export type AccountRole = (typeof ACCOUNT_ROLES)[number];

export const accountSchema = z.object({
  id: z.string(),
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Enter a valid email"),
  password: z.string().min(4, "Use at least 4 characters"),
  role: z.enum(ACCOUNT_ROLES),
  linkCode: z.string().min(4),
  careCircleName: z.string().min(1),
  linkedAccountIds: z.array(z.string()).default([]),
});
export type AppAccount = z.infer<typeof accountSchema>;

export const insertAccountSchema = accountSchema.omit({
  id: true,
  linkCode: true,
  linkedAccountIds: true,
});
export type InsertAccount = z.infer<typeof insertAccountSchema>;
