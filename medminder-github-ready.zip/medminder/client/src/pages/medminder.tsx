import { useEffect, useMemo, useState, useCallback } from "react";
import {
  Pill,
  Bell,
  Plus,
  Check,
  X,
  Clock,
  Sparkles,
  HeartPulse,
  CalendarClock,
  ChevronRight,
  AlertTriangle,
  Languages,
  UserRound,
  Stethoscope,
  Send,
  Trash2,
  Activity,
  ClipboardList,
  ShieldCheck,
  Link2,
  LogOut,
  UsersRound,
  KeyRound,
  Mail,
  LockKeyhole,
} from "lucide-react";

import type { AppAccount, DoseLog, Medication, TimeSlot } from "@shared/schema";
import { TIME_SLOTS, accountSchema, medicationSchema } from "@shared/schema";

import {
  buildTodaysDoses,
  defaultTimeForSlot,
  formatClock,
  isoToday,
  medicationTimeForSlot,
  newId,
  scheduleKey,
  slotColorVar,
  slotEmoji,
  translations,
  type DueDose,
  type Lang,
  type Role,
} from "@/lib/medminder";

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------
   Seed data — gives the prototype something to demo on first load
   ------------------------------------------------------------------ */
const SEED_MEDS: Medication[] = [
  {
    id: "med_vitd",
    name: "Vitamin D",
    dosage: "1 tablet",
    schedule: ["morning"],
    times: { morning: "08:30" },
    notes: "Take with breakfast.",
    color: "teal",
    addedBy: "carer",
  },
  {
    id: "med_omega",
    name: "Omega 3",
    dosage: "2 capsules",
    schedule: ["evening"],
    times: { evening: "19:00" },
    notes: "Take with dinner.",
    color: "orange",
    addedBy: "carer",
  },
  {
    id: "med_metf",
    name: "Metformin",
    dosage: "500 mg",
    schedule: ["morning", "evening"],
    times: { morning: "07:45", evening: "20:15" },
    notes: "Avoid alcohol.",
    color: "green",
    addedBy: "carer",
  },
];

const SEED_LOGS: DoseLog[] = [
  {
    id: "log_seed_1",
    medicationId: "med_omega",
    medicationName: "Omega 3",
    slot: "evening",
    scheduledFor: new Date(new Date().setHours(19, 0, 0, 0)).toISOString(),
    status: "taken",
    recordedAt: new Date(new Date().setHours(18, 30, 0, 0)).toISOString(),
    takenAt: new Date(new Date().setHours(18, 30, 0, 0)).toISOString(),
  },
];

const SEED_ACCOUNTS: AppAccount[] = [
  {
    id: "acct_patient_maria",
    name: "Maria Patient",
    email: "patient@medminder.app",
    password: "1234",
    role: "patient",
    linkCode: "PAT-4821",
    careCircleName: "Maria's care circle",
    linkedAccountIds: ["acct_carer_ana"],
  },
  {
    id: "acct_carer_ana",
    name: "Ana Carer",
    email: "carer@medminder.app",
    password: "1234",
    role: "carer",
    linkCode: "CAR-7390",
    careCircleName: "Maria's care circle",
    linkedAccountIds: ["acct_patient_maria"],
  },
];

/* ------------------------------------------------------------------
   Phone-style popup notification
   ------------------------------------------------------------------ */
type PhoneNotice = {
  id: string;
  variant: "reminder" | "taken" | "missed" | "added";
  title: string;
  body: string;
  appName: string;
  meta?: string;
  actions?: { label: string; onClick: () => void; primary?: boolean }[];
};

function PhoneNotification({
  notice,
  onDismiss,
}: {
  notice: PhoneNotice | null;
  onDismiss: () => void;
}) {
  if (!notice) return null;
  const ringTone =
    notice.variant === "reminder"
      ? "bg-[hsl(var(--md-orange))]"
      : notice.variant === "missed"
        ? "bg-[hsl(var(--destructive))]"
        : "bg-[hsl(var(--md-teal))]";
  return (
    <div
      className="fixed left-1/2 top-3 z-[120] w-[min(380px,calc(100vw-1.5rem))] -translate-x-1/2 md-anim-slide-down"
      data-testid="phone-notification"
      role="status"
      aria-live="polite"
    >
      <div className="rounded-[22px] border border-black/10 bg-white/95 p-3 shadow-xl backdrop-blur-md dark:border-white/10 dark:bg-zinc-900/90">
        <div className="flex items-start gap-3">
          <div className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-[10px]", ringTone)}>
            {notice.variant === "reminder" ? (
              <Bell className="h-4 w-4 text-white" strokeWidth={2.5} />
            ) : notice.variant === "missed" ? (
              <AlertTriangle className="h-4 w-4 text-white" strokeWidth={2.5} />
            ) : notice.variant === "added" ? (
              <Sparkles className="h-4 w-4 text-white" strokeWidth={2.5} />
            ) : (
              <Check className="h-4 w-4 text-white" strokeWidth={3} />
            )}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-baseline justify-between gap-2">
              <span className="truncate text-[11px] font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
                {notice.appName}
              </span>
              <span className="shrink-0 text-[11px] text-zinc-400">{notice.meta ?? "now"}</span>
            </div>
            <div
              className="mt-0.5 truncate text-[14px] font-semibold leading-tight text-zinc-900 dark:text-zinc-50"
              data-testid="text-notification-title"
            >
              {notice.title}
            </div>
            <div
              className="mt-0.5 text-[13px] leading-snug text-zinc-600 dark:text-zinc-300"
              data-testid="text-notification-body"
            >
              {notice.body}
            </div>
            {notice.actions && notice.actions.length > 0 && (
              <div className="mt-2 flex gap-2">
                {notice.actions.map((a, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      a.onClick();
                      onDismiss();
                    }}
                    className={cn(
                      "rounded-full px-3 py-1 text-[12px] font-medium transition-all",
                      a.primary
                        ? "bg-[hsl(var(--md-teal))] text-white hover:opacity-90"
                        : "bg-zinc-100 text-zinc-700 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-200"
                    )}
                    data-testid={`button-notification-action-${i}`}
                  >
                    {a.label}
                  </button>
                ))}
              </div>
            )}
          </div>
          <button
            onClick={onDismiss}
            className="-mr-1 -mt-1 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700 dark:hover:bg-zinc-800"
            aria-label="Dismiss notification"
            data-testid="button-dismiss-notification"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------
   Lightweight toast (briefer confirmations)
   ------------------------------------------------------------------ */
function InlineToast({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <div
      className="fixed bottom-24 left-1/2 z-[110] -translate-x-1/2 md-anim-fade-in"
      role="status"
      data-testid="toast-confirmation"
    >
      <div className="flex items-center gap-2 rounded-full bg-[hsl(var(--md-soft-green-deep))] px-4 py-2 text-sm font-semibold text-white shadow-lg">
        <Check className="h-4 w-4" strokeWidth={3} /> {message}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------
   Status chip
   ------------------------------------------------------------------ */
function StatusBadge({ status, label }: { status: DueDose["status"]; label: string }) {
  if (status === "taken") {
    return (
      <span
        className="inline-flex items-center gap-1 rounded-full bg-[hsl(var(--md-soft-green)/0.35)] px-2.5 py-0.5 text-[12px] font-semibold text-[hsl(var(--md-soft-green-deep))]"
        data-testid={`badge-status-${status}`}
      >
        <Check className="h-3 w-3" strokeWidth={3} /> {label}
      </span>
    );
  }
  if (status === "missed") {
    return (
      <span
        className="inline-flex items-center gap-1 rounded-full bg-[hsl(var(--destructive)/0.12)] px-2.5 py-0.5 text-[12px] font-semibold text-[hsl(var(--destructive))]"
        data-testid={`badge-status-${status}`}
      >
        <AlertTriangle className="h-3 w-3" /> {label}
      </span>
    );
  }
  return (
    <span
      className="inline-flex items-center gap-1 rounded-full bg-[hsl(var(--md-orange)/0.18)] px-2.5 py-0.5 text-[12px] font-semibold text-[hsl(var(--md-orange-dark))]"
      data-testid={`badge-status-${status}`}
    >
      <Clock className="h-3 w-3" /> {label}
    </span>
  );
}

function SlotChip({ slot, label }: { slot: TimeSlot; label: string }) {
  return (
    <span
      className="inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] font-semibold text-white"
      style={{ backgroundColor: `hsl(${slotColorVar[slot]})` }}
      data-testid={`badge-slot-${slot}`}
    >
      <span aria-hidden>{slotEmoji[slot]}</span> {label}
    </span>
  );
}

/* ------------------------------------------------------------------
   PillIcon — tiny SVG of a two-tone capsule
   ------------------------------------------------------------------ */
function PillIcon({ tone = "default" }: { tone?: "default" | "morning" | "evening" | "afternoon" | "night" }) {
  const colors: Record<string, [string, string]> = {
    default: ["hsl(var(--md-orange))", "hsl(45 80% 80%)"],
    morning: ["hsl(var(--md-orange))", "hsl(45 80% 80%)"],
    afternoon: ["hsl(var(--md-orange-dark))", "hsl(40 60% 75%)"],
    evening: ["hsl(262 50% 65%)", "hsl(45 70% 82%)"],
    night: ["hsl(220 25% 33%)", "hsl(220 15% 75%)"],
  };
  const [a, b] = colors[tone] ?? colors.default;
  return (
    <svg viewBox="0 0 48 48" className="h-10 w-10" aria-hidden>
      <g transform="rotate(-35 24 24)">
        <rect x="6" y="18" width="18" height="12" rx="6" fill={a} />
        <rect x="24" y="18" width="18" height="12" rx="6" fill={b} />
        <line x1="24" y1="19" x2="24" y2="29" stroke="hsl(var(--md-cream))" strokeWidth="1.2" />
        <rect x="9" y="20.5" width="4" height="2" rx="1" fill="rgba(255,255,255,0.45)" />
      </g>
    </svg>
  );
}

function pillToneForSlot(slot: TimeSlot): "morning" | "afternoon" | "evening" | "night" {
  return slot;
}

/* ------------------------------------------------------------------
   Logo (inline SVG, no system-font fallback)
   ------------------------------------------------------------------ */
function MedminderLogo({ className = "" }: { className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-2", className)}>
      <span className="inline-flex h-8 w-8 items-center justify-center rounded-[10px] bg-white/15 backdrop-blur-sm">
        <svg viewBox="0 0 32 32" className="h-5 w-5" aria-hidden>
          <g transform="rotate(-35 16 16)">
            <rect x="3" y="11" width="13" height="10" rx="5" fill="#E8845A" />
            <rect x="16" y="11" width="13" height="10" rx="5" fill="#F4E4B5" />
            <line x1="16" y1="12" x2="16" y2="20" stroke="#fff" strokeWidth="1.1" />
          </g>
        </svg>
      </span>
      <span className="font-display text-[22px] font-semibold tracking-tight text-white">Medminder</span>
    </span>
  );
}

function makeLinkCode(role: Role): string {
  const prefix = role === "patient" ? "PAT" : "CAR";
  return `${prefix}-${Math.floor(1000 + Math.random() * 9000)}`;
}

function normalizeCode(code: string): string {
  return code.trim().toUpperCase().replace(/\s+/g, "");
}

/* ------------------------------------------------------------------
   Main app
   ------------------------------------------------------------------ */
type Tab = "meds" | "log" | "overview";

export default function MedminderApp() {
  const [lang, setLang] = useState<Lang>("en");
  const [accounts, setAccounts] = useState<AppAccount[]>(SEED_ACCOUNTS);
  const [currentAccountId, setCurrentAccountId] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>("meds");
  const [medications, setMedications] = useState<Medication[]>(SEED_MEDS);
  const [logs, setLogs] = useState<DoseLog[]>(SEED_LOGS);
  const [showAdd, setShowAdd] = useState(false);
  const [notice, setNotice] = useState<PhoneNotice | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const t = translations[lang];
  const currentAccount = accounts.find((account) => account.id === currentAccountId) ?? null;
  const role: Role = currentAccount?.role ?? "patient";
  const linkedAccounts = currentAccount
    ? accounts.filter((account) => currentAccount.linkedAccountIds.includes(account.id))
    : [];

  const dismissNotice = useCallback(() => setNotice(null), []);

  const signIn = useCallback(
    (email: string, password: string) => {
      const account = accounts.find(
        (candidate) =>
          candidate.email.toLowerCase() === email.trim().toLowerCase() && candidate.password === password
      );
      if (!account) return false;
      setCurrentAccountId(account.id);
      setTab(account.role === "carer" ? "overview" : "meds");
      return true;
    },
    [accounts]
  );

  const createAccount = useCallback(
    (input: { name: string; email: string; password: string; role: Role; careCircleName: string }) => {
      const parsed = accountSchema.safeParse({
        id: newId(),
        ...input,
        linkCode: makeLinkCode(input.role),
        linkedAccountIds: [],
      });
      if (!parsed.success) return false;
      setAccounts((prev) => [...prev, parsed.data]);
      setCurrentAccountId(parsed.data.id);
      setTab(parsed.data.role === "carer" ? "overview" : "meds");
      setNotice({
        id: newId(),
        appName: t.brand,
        variant: "added",
        title: t.accountCreated(parsed.data.name),
        body: `${t.linkCode}: ${parsed.data.linkCode}`,
        meta: "now",
      });
      return true;
    },
    [t]
  );

  const linkAccount = useCallback(
    (code: string) => {
      if (!currentAccount) return { ok: false, message: t.codeNotFound };
      const target = accounts.find(
        (account) => account.linkCode === normalizeCode(code) && account.id !== currentAccount.id
      );
      if (!target) return { ok: false, message: t.codeNotFound };
      if (currentAccount.linkedAccountIds.includes(target.id)) {
        return { ok: false, message: t.alreadyLinked };
      }
      setAccounts((prev) =>
        prev.map((account) => {
          if (account.id === currentAccount.id) {
            return { ...account, linkedAccountIds: [...account.linkedAccountIds, target.id] };
          }
          if (account.id === target.id) {
            return { ...account, linkedAccountIds: [...account.linkedAccountIds, currentAccount.id] };
          }
          return account;
        })
      );
      setNotice({
        id: newId(),
        appName: t.brand,
        variant: "added",
        title: t.linkedNotice(target.name),
        body: `${currentAccount.careCircleName} · ${target.role === "carer" ? t.carer : t.patient}`,
        meta: "now",
      });
      return { ok: true, message: t.linkedNotice(target.name) };
    },
    [accounts, currentAccount, t]
  );

  // Auto-dismiss the popup after a while
  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(null), 6000);
    return () => window.clearTimeout(timer);
  }, [notice]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 2200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const today = isoToday();
  const doses = useMemo(() => buildTodaysDoses(medications, logs, today), [medications, logs, today]);

  const takenCount = doses.filter((d) => d.status === "taken").length;
  const pendingCount = doses.filter((d) => d.status === "pending").length;
  const missedCount = doses.filter((d) => d.status === "missed").length;
  const adherence = doses.length === 0 ? 0 : Math.round((takenCount / doses.length) * 100);

  const markDose = useCallback(
    (dose: DueDose, status: DoseLog["status"]) => {
      const now = new Date().toISOString();
      setLogs((prev) => {
        const existing = prev.find((l) => scheduleKey(l.medicationId, l.slot, today) === dose.key);
        if (existing) {
          return prev.map((l) =>
            l.id === existing.id
              ? {
                  ...l,
                  status,
                  recordedAt: now,
                  takenAt: status === "taken" ? now : undefined,
                }
              : l
          );
        }
        const next: DoseLog = {
          id: newId(),
          medicationId: dose.medication.id,
          medicationName: dose.medication.name,
          slot: dose.slot,
          scheduledFor: dose.scheduledFor,
          status,
          recordedAt: now,
          takenAt: status === "taken" ? now : undefined,
        };
        return [...prev, next];
      });

      if (status === "taken") {
        setToast(t.markedTaken);
        setNotice({
          id: newId(),
          appName: t.brand,
          variant: "taken",
          title: t.takenNotice(dose.medication.name),
          body: `${dose.medication.dosage} · ${t.times[dose.slot]} · ${formatClock(now)}`,
          meta: "now",
        });
      } else if (status === "missed") {
        setNotice({
          id: newId(),
          appName: t.brand,
          variant: "missed",
          title: t.missedNotice(dose.medication.name, t.times[dose.slot]),
          body: dose.medication.dosage,
          meta: "now",
        });
      }
    },
    [t, today]
  );

  const sendReminder = useCallback(
    (dose: DueDose) => {
      setNotice({
        id: newId(),
        appName: t.brand,
        variant: "reminder",
        title: t.reminderTitle(dose.medication.name),
        body: `${t.reminderBody(dose.medication.dosage, t.times[dose.slot])} · ${medicationTimeForSlot(dose.medication, dose.slot)}`,
        meta: "now",
        actions: [
          {
            label: t.markedTaken,
            primary: true,
            onClick: () => markDose(dose, "taken"),
          },
        ],
      });
    },
    [t, markDose]
  );

  const addMedication = useCallback(
    (input: { name: string; dosage: string; schedule: TimeSlot[]; times: Record<string, string>; notes?: string }) => {
      const parsed = medicationSchema.safeParse({
        id: newId(),
        ...input,
        notes: input.notes ?? "",
        color: "teal",
        addedBy: role,
      });
      if (!parsed.success) return false;
      setMedications((prev) => [...prev, parsed.data]);
      setNotice({
        id: newId(),
        appName: t.brand,
        variant: "added",
        title: t.addedNotice(parsed.data.name),
        body: `${parsed.data.dosage} · ${parsed.data.schedule
          .map((s) => `${t.times[s]} ${medicationTimeForSlot(parsed.data, s)}`)
          .join(", ")}`,
        meta: "now",
      });
      return true;
    },
    [role, t]
  );

  const removeMed = useCallback(
    (id: string) => {
      const med = medications.find((m) => m.id === id);
      setMedications((prev) => prev.filter((m) => m.id !== id));
      setLogs((prev) => prev.filter((l) => l.medicationId !== id));
      if (med) setToast(`${med.name} · ${t.removed}`);
    },
    [medications, t]
  );

  // Carer can see all tabs; patient sees meds + log
  const availableTabs: Tab[] = role === "carer" ? ["meds", "overview", "log"] : ["meds", "log"];
  useEffect(() => {
    if (!availableTabs.includes(tab)) setTab("meds");
  }, [role, tab, availableTabs]);

  if (!currentAccount) {
    return (
      <AuthScreen
        t={t}
        lang={lang}
        onToggleLang={() => setLang(lang === "en" ? "pt" : "en")}
        onSignIn={signIn}
        onCreateAccount={createAccount}
      />
    );
  }

  return (
    <div className="min-h-[100dvh] bg-background text-foreground" data-testid="app-root">
      <PhoneNotification notice={notice} onDismiss={dismissNotice} />
      <InlineToast message={toast} />

      {/* ============================
          Mobile-first frame
          ============================ */}
      <div className="mx-auto flex max-w-[480px] flex-col md:max-w-[460px]">
        {/* Header */}
        <header className="relative overflow-hidden bg-[hsl(var(--md-teal))] px-5 pb-24 pt-7 text-white">
          <div
            aria-hidden
            className="absolute -right-12 -top-12 h-44 w-44 rounded-full bg-white/10 blur-2xl"
          />
          <div
            aria-hidden
            className="absolute -left-10 bottom-0 h-32 w-32 rounded-full bg-black/10 blur-2xl"
          />
          <div className="relative flex items-start justify-between">
            <div>
              <MedminderLogo />
              <p className="mt-1 text-[13px] text-white/80">{t.tagline}</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setLang(lang === "en" ? "pt" : "en")}
                className="inline-flex items-center gap-1 rounded-full bg-white/15 px-3 py-1.5 text-[12px] font-semibold backdrop-blur-sm hover:bg-white/25"
                aria-label="Toggle language"
                data-testid="button-language-toggle"
              >
                <Languages className="h-3.5 w-3.5" /> {t.language}
              </button>
            </div>
          </div>

          {/* Signed-in account */}
          <div className="relative mt-5 rounded-[18px] bg-white/15 p-3 backdrop-blur-sm" data-testid="card-current-account">
            <div className="flex items-center justify-between gap-3">
              <div className="flex min-w-0 items-center gap-3">
                <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-white text-[hsl(var(--md-teal-dark))]">
                  {role === "carer" ? <Stethoscope className="h-5 w-5" /> : <UserRound className="h-5 w-5" />}
                </div>
                <div className="min-w-0">
                  <p className="text-[11px] font-semibold uppercase tracking-wider text-white/70">{t.linkedAs}</p>
                  <p className="truncate text-[14px] font-semibold text-white" data-testid="text-current-account-name">
                    {currentAccount.name}
                  </p>
                  <p className="text-[12px] text-white/75" data-testid="text-current-account-role">
                    {role === "carer" ? t.carer : t.patient} · {currentAccount.careCircleName}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setCurrentAccountId(null);
                  setTab("meds");
                }}
                className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white/15 text-white hover:bg-white/25"
                aria-label={t.signOut}
                data-testid="button-sign-out"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          </div>
        </header>

        {/* Floating summary card overlapping header */}
        <section className="relative px-4">
          <div
            className="-mt-14 rounded-[20px] border border-[hsl(var(--md-border))] bg-[hsl(var(--md-cream-card))] px-4 pb-4 pt-5 shadow-lg"
            data-testid="card-progress-summary"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="text-[12px] font-semibold uppercase tracking-wider text-[hsl(var(--md-muted))]">
                  {t.todaysProgress}
                </p>
                <p className="mt-2 text-[18px] font-semibold leading-snug tracking-tight text-foreground" data-testid="text-progress-headline">
                  {t.takenCount(takenCount, doses.length)}
                </p>
              </div>
              <div className="flex flex-col items-end">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-[hsl(var(--md-muted))]">
                  {t.adherence}
                </span>
                <span
                  className="mt-1 text-[26px] font-semibold leading-none tracking-tight text-[hsl(var(--md-teal-dark))]"
                  data-testid="text-adherence-percent"
                >
                  {adherence}%
                </span>
              </div>
            </div>

            <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-[hsl(var(--md-border))]">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[hsl(var(--md-teal))] to-[hsl(var(--md-soft-green-deep))] transition-all duration-500"
                style={{ width: `${adherence}%` }}
                data-testid="bar-adherence"
              />
            </div>

            <div className="mt-3 flex flex-wrap gap-1.5">
              <Badge variant="secondary" className="bg-[hsl(var(--md-soft-green)/0.4)] text-[hsl(var(--md-soft-green-deep))] hover:bg-[hsl(var(--md-soft-green)/0.4)]" data-testid="badge-taken-count">
                <Check className="mr-1 h-3 w-3" strokeWidth={3} /> {takenCount} {t.status.taken.toLowerCase()}
              </Badge>
              <Badge variant="secondary" className="bg-[hsl(var(--md-orange)/0.18)] text-[hsl(var(--md-orange-dark))] hover:bg-[hsl(var(--md-orange)/0.18)]" data-testid="badge-pending-count">
                <Clock className="mr-1 h-3 w-3" /> {t.pendingCount(pendingCount)}
              </Badge>
              {missedCount > 0 && (
                <Badge variant="secondary" className="bg-[hsl(var(--destructive)/0.12)] text-[hsl(var(--destructive))] hover:bg-[hsl(var(--destructive)/0.12)]" data-testid="badge-missed-count">
                  <AlertTriangle className="mr-1 h-3 w-3" /> {t.missedCount(missedCount)}
                </Badge>
              )}
            </div>

            <p className="mt-3 flex items-center gap-1.5 text-[12px] text-[hsl(var(--md-muted))]">
              <HeartPulse className="h-3.5 w-3.5 text-[hsl(var(--md-orange))]" /> {role === "patient" ? t.patientSubtitle : t.carerSubtitle}
            </p>
          </div>
        </section>

        <section className="mt-3 px-4">
          <LinkAccountsCard
            account={currentAccount}
            linkedAccounts={linkedAccounts}
            t={t}
            onLink={linkAccount}
          />
        </section>

        {/* Tabs */}
        <nav
          className="sticky top-0 z-30 mt-5 border-b border-[hsl(var(--md-border))] bg-background/95 px-2 backdrop-blur-md"
          role="tablist"
          aria-label="Sections"
        >
          <div className="flex">
            {availableTabs.map((tb) => {
              const label =
                tb === "meds" ? t.myMeds : tb === "log" ? t.log : t.overview;
              const Icon = tb === "meds" ? Pill : tb === "log" ? ClipboardList : Activity;
              const active = tab === tb;
              return (
                <button
                  key={tb}
                  role="tab"
                  aria-selected={active}
                  onClick={() => setTab(tb)}
                  className={cn(
                    "relative flex flex-1 items-center justify-center gap-1.5 py-3 text-[13px] font-semibold transition-colors",
                    active
                      ? "text-[hsl(var(--md-teal-dark))]"
                      : "text-[hsl(var(--md-muted))] hover:text-foreground"
                  )}
                  data-testid={`tab-${tb}`}
                >
                  <Icon className="h-4 w-4" />
                  {label}
                  {active && (
                    <span className="absolute -bottom-[1px] left-1/4 right-1/4 h-[3px] rounded-full bg-[hsl(var(--md-teal))]" />
                  )}
                </button>
              );
            })}
          </div>
        </nav>

        {/* Content */}
        <main className="px-4 pb-32 pt-4">
          {tab === "meds" && (
            <MedsTab
              doses={doses}
              meds={medications}
              role={role}
              t={t}
              onMarkTaken={(d) => markDose(d, "taken")}
              onMarkMissed={(d) => markDose(d, "missed")}
              onSendReminder={sendReminder}
              onRemove={removeMed}
              onAdd={() => setShowAdd(true)}
            />
          )}
          {tab === "log" && <LogTab logs={logs} t={t} />}
          {tab === "overview" && role === "carer" && (
            <OverviewTab
              doses={doses}
              meds={medications}
              logs={logs}
              t={t}
              onSendReminder={sendReminder}
              onMarkMissed={(d) => markDose(d, "missed")}
            />
          )}
        </main>

        {/* Floating add button — only for carers */}
        {role === "carer" && (
          <button
            onClick={() => setShowAdd(true)}
            className="md-pulse-ring fixed bottom-6 left-1/2 z-40 inline-flex -translate-x-1/2 items-center gap-2 rounded-full bg-[hsl(var(--md-orange))] px-6 py-3.5 font-display text-[15px] font-semibold text-white shadow-[0_12px_30px_-8px_hsl(var(--md-orange)/0.7)] transition-transform hover:scale-[1.02] active:scale-[0.98]"
            data-testid="button-open-add-medication"
          >
            <Plus className="h-5 w-5" strokeWidth={2.5} /> {t.addMed}
          </button>
        )}
      </div>

      {/* Add medication dialog */}
      <AddMedicationDialog
        open={showAdd}
        onOpenChange={setShowAdd}
        t={t}
        onSubmit={(input) => {
          const ok = addMedication(input);
          if (ok) setShowAdd(false);
          return ok;
        }}
      />
    </div>
  );
}

/* ------------------------------------------------------------------
   Login and account linking
   ------------------------------------------------------------------ */
function AuthScreen({
  t,
  lang,
  onToggleLang,
  onSignIn,
  onCreateAccount,
}: {
  t: typeof translations.en;
  lang: Lang;
  onToggleLang: () => void;
  onSignIn: (email: string, password: string) => boolean;
  onCreateAccount: (input: {
    name: string;
    email: string;
    password: string;
    role: Role;
    careCircleName: string;
  }) => boolean;
}) {
  const [mode, setMode] = useState<"login" | "create">("login");
  const [email, setEmail] = useState("patient@medminder.app");
  const [password, setPassword] = useState("1234");
  const [name, setName] = useState("");
  const [role, setRole] = useState<Role>("patient");
  const [careCircleName, setCareCircleName] = useState("Family care circle");
  const [error, setError] = useState<string | null>(null);

  const submitLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!onSignIn(email, password)) setError(t.loginError);
  };

  const submitCreate = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const ok = onCreateAccount({
      name: name.trim(),
      email: email.trim(),
      password,
      role,
      careCircleName: careCircleName.trim() || "Family care circle",
    });
    if (!ok) setError(t.loginError);
  };

  const fillDemo = (nextRole: Role) => {
    setMode("login");
    setRole(nextRole);
    setEmail(nextRole === "patient" ? "patient@medminder.app" : "carer@medminder.app");
    setPassword("1234");
    setError(null);
  };

  return (
    <div className="min-h-[100dvh] bg-background text-foreground" data-testid="auth-root">
      <div className="mx-auto flex min-h-[100dvh] max-w-[480px] flex-col justify-center px-5 py-8 md:max-w-[460px]">
        <div className="overflow-hidden rounded-[28px] border border-[hsl(var(--md-border))] bg-[hsl(var(--md-cream-card))] shadow-xl">
          <div className="relative overflow-hidden bg-[hsl(var(--md-teal))] px-5 pb-8 pt-6 text-white">
            <div aria-hidden className="absolute -right-12 -top-10 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
            <div className="relative flex items-start justify-between gap-3">
              <div>
                <MedminderLogo />
                <h1 className="mt-6 font-display text-[24px] font-semibold leading-tight" data-testid="title-login">
                  {t.loginTitle}
                </h1>
                <p className="mt-2 max-w-[320px] text-[13px] leading-relaxed text-white/80">
                  {t.loginSubtitle}
                </p>
              </div>
              <button
                onClick={onToggleLang}
                className="inline-flex items-center gap-1 rounded-full bg-white/15 px-3 py-1.5 text-[12px] font-semibold backdrop-blur-sm hover:bg-white/25"
                aria-label="Toggle language"
                data-testid="button-auth-language-toggle"
              >
                <Languages className="h-3.5 w-3.5" /> {lang === "en" ? "PT" : "EN"}
              </button>
            </div>
          </div>

          <div className="-mt-5 px-4">
            <div className="grid grid-cols-2 gap-2 rounded-full bg-white p-1 shadow-lg">
              <button
                onClick={() => setMode("login")}
                className={cn(
                  "rounded-full px-3 py-2 text-[13px] font-semibold transition-all",
                  mode === "login" ? "bg-[hsl(var(--md-teal))] text-white" : "text-[hsl(var(--md-muted))]"
                )}
                data-testid="button-mode-login"
              >
                {t.signIn}
              </button>
              <button
                onClick={() => setMode("create")}
                className={cn(
                  "rounded-full px-3 py-2 text-[13px] font-semibold transition-all",
                  mode === "create" ? "bg-[hsl(var(--md-teal))] text-white" : "text-[hsl(var(--md-muted))]"
                )}
                data-testid="button-mode-create"
              >
                {t.createAccount}
              </button>
            </div>
          </div>

          <div className="px-5 py-5">
            {mode === "login" && (
              <div className="mb-4 grid grid-cols-2 gap-2">
                <Button
                  type="button"
                  variant="outline"
                  className="rounded-xl border-[hsl(var(--md-teal)/0.35)] bg-white"
                  onClick={() => fillDemo("patient")}
                  data-testid="button-demo-patient"
                >
                  <UserRound className="mr-1 h-4 w-4" /> {t.demoPatient}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="rounded-xl border-[hsl(var(--md-teal)/0.35)] bg-white"
                  onClick={() => fillDemo("carer")}
                  data-testid="button-demo-carer"
                >
                  <Stethoscope className="mr-1 h-4 w-4" /> {t.demoCarer}
                </Button>
              </div>
            )}

            <form onSubmit={mode === "login" ? submitLogin : submitCreate} className="space-y-3">
              {mode === "create" && (
                <>
                  <div>
                    <Label htmlFor="auth-name" className="text-[13px] font-semibold">
                      {t.fullName}
                    </Label>
                    <div className="relative mt-1">
                      <UserRound className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[hsl(var(--md-muted))]" />
                      <Input
                        id="auth-name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="h-11 rounded-xl border-[hsl(var(--md-border))] bg-white pl-9"
                        data-testid="input-auth-name"
                      />
                    </div>
                  </div>

                  <div>
                    <Label className="text-[13px] font-semibold">{t.accountType}</Label>
                    <div className="mt-1 grid grid-cols-2 gap-2">
                      {(["patient", "carer"] as Role[]).map((r) => (
                        <button
                          type="button"
                          key={r}
                          onClick={() => setRole(r)}
                          className={cn(
                            "flex items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-[13px] font-semibold transition-all",
                            role === r
                              ? "border-transparent bg-[hsl(var(--md-teal))] text-white"
                              : "border-[hsl(var(--md-border))] bg-white text-[hsl(var(--md-muted))]"
                          )}
                          data-testid={`button-create-role-${r}`}
                        >
                          {r === "carer" ? <Stethoscope className="h-4 w-4" /> : <UserRound className="h-4 w-4" />}
                          {r === "carer" ? t.carer : t.patient}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="auth-circle" className="text-[13px] font-semibold">
                      {t.careCircle}
                    </Label>
                    <Input
                      id="auth-circle"
                      value={careCircleName}
                      onChange={(e) => setCareCircleName(e.target.value)}
                      className="mt-1 h-11 rounded-xl border-[hsl(var(--md-border))] bg-white"
                      data-testid="input-auth-care-circle"
                    />
                  </div>
                </>
              )}

              <div>
                <Label htmlFor="auth-email" className="text-[13px] font-semibold">
                  {t.email}
                </Label>
                <div className="relative mt-1">
                  <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[hsl(var(--md-muted))]" />
                  <Input
                    id="auth-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="h-11 rounded-xl border-[hsl(var(--md-border))] bg-white pl-9"
                    data-testid="input-auth-email"
                    autoComplete="email"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="auth-password" className="text-[13px] font-semibold">
                  {t.password}
                </Label>
                <div className="relative mt-1">
                  <LockKeyhole className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[hsl(var(--md-muted))]" />
                  <Input
                    id="auth-password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="h-11 rounded-xl border-[hsl(var(--md-border))] bg-white pl-9"
                    data-testid="input-auth-password"
                    autoComplete={mode === "login" ? "current-password" : "new-password"}
                  />
                </div>
              </div>

              {error && (
                <p className="rounded-xl bg-[hsl(var(--destructive)/0.1)] px-3 py-2 text-[13px] font-medium text-[hsl(var(--destructive))]" data-testid="text-auth-error">
                  {error}
                </p>
              )}

              <Button
                type="submit"
                className="h-12 w-full rounded-xl bg-[hsl(var(--md-orange))] font-display text-[15px] font-semibold text-white shadow-[0_8px_22px_-8px_hsl(var(--md-orange)/0.7)] hover:bg-[hsl(var(--md-orange-dark))]"
                data-testid={mode === "login" ? "button-submit-login" : "button-submit-create"}
              >
                {mode === "login" ? t.signIn : t.createAccount}
              </Button>
            </form>

            <div className="mt-4 rounded-[16px] bg-[hsl(var(--md-cream))] p-3 text-[12px] leading-relaxed text-[hsl(var(--md-muted))]">
              <KeyRound className="mr-1 inline h-3.5 w-3.5 text-[hsl(var(--md-teal))]" />
              patient@medminder.app / 1234 · carer@medminder.app / 1234
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function LinkAccountsCard({
  account,
  linkedAccounts,
  t,
  onLink,
}: {
  account: AppAccount;
  linkedAccounts: AppAccount[];
  t: typeof translations.en;
  onLink: (code: string) => { ok: boolean; message: string };
}) {
  const [code, setCode] = useState("");
  const [message, setMessage] = useState<string | null>(null);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = onLink(code);
    setMessage(result.message);
    if (result.ok) setCode("");
  };

  return (
    <div className="rounded-[18px] border border-[hsl(var(--md-border))] bg-[hsl(var(--md-cream-card))] p-4 shadow-sm" data-testid="card-link-accounts">
      <div className="flex items-start gap-3">
        <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[hsl(var(--md-teal)/0.12)] text-[hsl(var(--md-teal-dark))]">
          <Link2 className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <h2 className="font-display text-[16px] font-semibold">{t.linkAccounts}</h2>
          <p className="mt-0.5 text-[12px] text-[hsl(var(--md-muted))]">{t.shareCode}</p>
        </div>
      </div>

      <div className="mt-3 grid grid-cols-[1fr_auto] gap-2">
        <div className="rounded-[14px] bg-[hsl(var(--md-cream))] px-3 py-2">
          <p className="text-[10px] font-semibold uppercase tracking-wider text-[hsl(var(--md-muted))]">{t.linkCode}</p>
          <p className="font-display text-[20px] font-semibold tracking-wide text-[hsl(var(--md-teal-dark))]" data-testid="text-own-link-code">
            {account.linkCode}
          </p>
        </div>
        <div className="rounded-[14px] bg-[hsl(var(--md-soft-green)/0.35)] px-3 py-2 text-center">
          <UsersRound className="mx-auto h-4 w-4 text-[hsl(var(--md-soft-green-deep))]" />
          <p className="mt-1 text-[18px] font-semibold leading-none text-[hsl(var(--md-soft-green-deep))]" data-testid="text-linked-count">
            {linkedAccounts.length}
          </p>
        </div>
      </div>

      <form onSubmit={submit} className="mt-3 flex gap-2">
        <Input
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          placeholder={t.enterLinkCode}
          className="h-11 rounded-xl border-[hsl(var(--md-border))] bg-white text-[13px] uppercase tracking-wide"
          data-testid="input-link-code"
          autoComplete="off"
        />
        <Button
          type="submit"
          className="h-11 shrink-0 rounded-xl bg-[hsl(var(--md-teal))] hover:bg-[hsl(var(--md-teal-dark))]"
          data-testid="button-link-account"
        >
          <Link2 className="mr-1 h-4 w-4" /> {t.linkAccount}
        </Button>
      </form>

      {message && (
        <p className="mt-2 text-[12px] font-medium text-[hsl(var(--md-muted))]" data-testid="text-link-message">
          {message}
        </p>
      )}

      {linkedAccounts.length > 0 && (
        <div className="mt-3">
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-[hsl(var(--md-muted))]">
            {t.linkedAccounts}
          </p>
          <div className="flex flex-col gap-2" data-testid="list-linked-accounts">
            {linkedAccounts.map((linked) => (
              <div key={linked.id} className="flex items-center gap-2 rounded-[12px] bg-white px-3 py-2">
                {linked.role === "carer" ? (
                  <Stethoscope className="h-4 w-4 text-[hsl(var(--md-teal))]" />
                ) : (
                  <UserRound className="h-4 w-4 text-[hsl(var(--md-teal))]" />
                )}
                <span className="min-w-0 flex-1 truncate text-[13px] font-semibold" data-testid={`text-linked-account-${linked.id}`}>
                  {linked.name}
                </span>
                <span className="text-[11px] text-[hsl(var(--md-muted))]">
                  {linked.role === "carer" ? t.carer : t.patient}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------
   Tabs
   ------------------------------------------------------------------ */
function MedsTab({
  doses,
  meds,
  role,
  t,
  onMarkTaken,
  onMarkMissed,
  onSendReminder,
  onRemove,
  onAdd,
}: {
  doses: DueDose[];
  meds: Medication[];
  role: Role;
  t: typeof translations.en;
  onMarkTaken: (d: DueDose) => void;
  onMarkMissed: (d: DueDose) => void;
  onSendReminder: (d: DueDose) => void;
  onRemove: (id: string) => void;
  onAdd: () => void;
}) {
  if (meds.length === 0) {
    return (
      <div
        className="rounded-[20px] border border-dashed border-[hsl(var(--md-border))] bg-[hsl(var(--md-cream-card))] p-8 text-center"
        data-testid="empty-medications"
      >
        <div className="mx-auto inline-flex h-14 w-14 items-center justify-center rounded-full bg-[hsl(var(--md-cream))]">
          <Pill className="h-7 w-7 text-[hsl(var(--md-teal))]" />
        </div>
        <h3 className="mt-3 font-display text-[18px] font-semibold">{t.noMeds}</h3>
        <p className="mt-1 text-[13px] text-[hsl(var(--md-muted))]">
          {role === "patient" ? t.noMedsHintPatient : t.noMedsHintCarer}
        </p>
        {role === "carer" && (
          <Button
            onClick={onAdd}
            className="mt-4 bg-[hsl(var(--md-teal))] hover:bg-[hsl(var(--md-teal-dark))]"
            data-testid="button-add-medication-empty"
          >
            <Plus className="mr-1 h-4 w-4" /> {t.addMed}
          </Button>
        )}
      </div>
    );
  }

  return (
    <ul className="flex flex-col gap-3" data-testid="list-doses">
      {doses.map((d) => (
        <DoseCard
          key={d.key}
          dose={d}
          role={role}
          t={t}
          onMarkTaken={() => onMarkTaken(d)}
          onMarkMissed={() => onMarkMissed(d)}
          onSendReminder={() => onSendReminder(d)}
          onRemove={() => {
            if (window.confirm(t.removeConfirm)) onRemove(d.medication.id);
          }}
        />
      ))}
    </ul>
  );
}

function DoseCard({
  dose,
  role,
  t,
  onMarkTaken,
  onMarkMissed,
  onSendReminder,
  onRemove,
}: {
  dose: DueDose;
  role: Role;
  t: typeof translations.en;
  onMarkTaken: () => void;
  onMarkMissed: () => void;
  onSendReminder: () => void;
  onRemove: () => void;
}) {
  const taken = dose.status === "taken";
  const missed = dose.status === "missed";
  const id = dose.medication.id;

  return (
    <li
      className={cn(
        "relative overflow-hidden rounded-[20px] border bg-[hsl(var(--md-cream-card))] p-4 shadow-sm transition-all",
        taken
          ? "border-[hsl(var(--md-soft-green))]"
          : missed
            ? "border-[hsl(var(--destructive)/0.4)]"
            : "border-[hsl(var(--md-border))]"
      )}
      data-testid={`card-dose-${id}-${dose.slot}`}
    >
      <div className="flex items-start gap-3">
        <div className="grid h-12 w-12 shrink-0 place-items-center rounded-[14px] bg-[hsl(var(--md-cream))]">
          <PillIcon tone={pillToneForSlot(dose.slot)} />
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between gap-2">
            <h3
              className="truncate font-display text-[18px] font-semibold leading-tight text-foreground"
              data-testid={`text-medication-name-${id}`}
            >
              {dose.medication.name}
            </h3>
            {role === "carer" && (
              <button
                onClick={onRemove}
                aria-label={`${t.remove} ${dose.medication.name}`}
                className="-mr-1 -mt-1 inline-flex h-7 w-7 items-center justify-center rounded-full text-[hsl(var(--md-muted))] hover:bg-black/5 hover:text-[hsl(var(--destructive))]"
                data-testid={`button-remove-medication-${id}`}
              >
                <Trash2 className="h-4 w-4" />
              </button>
            )}
          </div>

          <p className="mt-0.5 text-[13px] text-[hsl(var(--md-muted))]" data-testid={`text-medication-dosage-${id}`}>
            {dose.medication.dosage} · {medicationTimeForSlot(dose.medication, dose.slot)}
          </p>

          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            <SlotChip slot={dose.slot} label={t.times[dose.slot]} />
            <StatusBadge status={dose.status} label={t.status[dose.status]} />
            {dose.takenAt && (
              <span
                className="inline-flex items-center gap-1 text-[12px] text-[hsl(var(--md-soft-green-deep))]"
                data-testid={`text-taken-at-${id}-${dose.slot}`}
              >
                <Check className="h-3 w-3" strokeWidth={3} /> {t.takenAt} {formatClock(dose.takenAt)}
              </span>
            )}
          </div>

          {dose.medication.notes && (
            <p className="mt-2 rounded-md bg-[hsl(var(--md-cream))] px-2 py-1 text-[12px] text-[hsl(var(--md-muted))]">
              {dose.medication.notes}
            </p>
          )}
        </div>
      </div>

      <div className="mt-3 flex gap-2">
        {role === "patient" ? (
          taken ? (
            <Button
              variant="ghost"
              disabled
              className="h-11 flex-1 cursor-default rounded-[14px] bg-[hsl(var(--md-soft-green)/0.45)] font-display text-[15px] font-semibold text-[hsl(var(--md-soft-green-deep))] hover:bg-[hsl(var(--md-soft-green)/0.45)]"
              data-testid={`button-taken-confirmed-${id}-${dose.slot}`}
            >
              <Check className="mr-1 h-4 w-4" strokeWidth={3} /> {t.taken}
            </Button>
          ) : (
            <Button
              onClick={onMarkTaken}
              className="h-11 flex-1 rounded-[14px] bg-[hsl(var(--md-orange))] font-display text-[15px] font-semibold text-white shadow-[0_6px_18px_-6px_hsl(var(--md-orange)/0.7)] hover:bg-[hsl(var(--md-orange-dark))]"
              data-testid={`button-mark-taken-${id}-${dose.slot}`}
            >
              <Check className="mr-1 h-4 w-4" strokeWidth={3} /> {t.markTaken}
            </Button>
          )
        ) : (
          <>
            <Button
              onClick={onSendReminder}
              variant="outline"
              className="h-11 flex-1 rounded-[14px] border-[hsl(var(--md-teal)/0.4)] bg-transparent font-display text-[14px] font-semibold text-[hsl(var(--md-teal-dark))] hover:bg-[hsl(var(--md-teal)/0.1)]"
              data-testid={`button-send-reminder-${id}-${dose.slot}`}
            >
              <Send className="mr-1 h-4 w-4" /> {t.simulateReminder}
            </Button>
            {!taken && !missed && (
              <Button
                onClick={onMarkMissed}
                variant="ghost"
                className="h-11 rounded-[14px] text-[hsl(var(--destructive))] hover:bg-[hsl(var(--destructive)/0.1)]"
                aria-label={t.missed}
                data-testid={`button-mark-missed-${id}-${dose.slot}`}
              >
                <AlertTriangle className="h-4 w-4" />
              </Button>
            )}
          </>
        )}
      </div>
    </li>
  );
}

function LogTab({ logs, t }: { logs: DoseLog[]; t: typeof translations.en }) {
  const sorted = useMemo(
    () => [...logs].sort((a, b) => b.recordedAt.localeCompare(a.recordedAt)),
    [logs]
  );

  if (sorted.length === 0) {
    return (
      <div
        className="rounded-[20px] border border-dashed border-[hsl(var(--md-border))] bg-[hsl(var(--md-cream-card))] p-8 text-center"
        data-testid="empty-log"
      >
        <ClipboardList className="mx-auto h-8 w-8 text-[hsl(var(--md-muted))]" />
        <p className="mt-2 text-[14px] text-[hsl(var(--md-muted))]">{t.noLog}</p>
      </div>
    );
  }

  return (
    <div>
      <h2 className="mb-3 font-display text-[18px] font-semibold">{t.logTitle}</h2>
      <ol className="flex flex-col gap-2" data-testid="list-log">
        {sorted.map((entry) => {
          const isTaken = entry.status === "taken";
          return (
            <li
              key={entry.id}
              className="flex items-center gap-3 rounded-[16px] border border-[hsl(var(--md-border))] bg-[hsl(var(--md-cream-card))] p-3"
              data-testid={`row-log-${entry.id}`}
            >
              <div
                className={cn(
                  "grid h-10 w-10 shrink-0 place-items-center rounded-full",
                  isTaken
                    ? "bg-[hsl(var(--md-soft-green)/0.45)] text-[hsl(var(--md-soft-green-deep))]"
                    : "bg-[hsl(var(--destructive)/0.12)] text-[hsl(var(--destructive))]"
                )}
              >
                {isTaken ? <Check className="h-4 w-4" strokeWidth={3} /> : <AlertTriangle className="h-4 w-4" />}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-display text-[15px] font-semibold leading-tight">
                  {entry.medicationName}
                </p>
                <p className="mt-0.5 text-[12px] text-[hsl(var(--md-muted))]">
                  {t.times[entry.slot]} ·{" "}
                  {isTaken && entry.takenAt
                    ? `${t.takenAt} ${formatClock(entry.takenAt)}`
                    : t.status[entry.status]}
                </p>
              </div>
              <StatusBadge status={entry.status} label={t.status[entry.status]} />
            </li>
          );
        })}
      </ol>
    </div>
  );
}

function OverviewTab({
  doses,
  meds,
  logs,
  t,
  onSendReminder,
  onMarkMissed,
}: {
  doses: DueDose[];
  meds: Medication[];
  logs: DoseLog[];
  t: typeof translations.en;
  onSendReminder: (d: DueDose) => void;
  onMarkMissed: (d: DueDose) => void;
}) {
  const pending = doses.filter((d) => d.status === "pending");
  const taken = doses.filter((d) => d.status === "taken");
  const missed = doses.filter((d) => d.status === "missed");

  return (
    <div className="flex flex-col gap-4">
      <section
        className="rounded-[20px] border border-[hsl(var(--md-border))] bg-[hsl(var(--md-cream-card))] p-4"
        data-testid="card-overview-totals"
      >
        <h2 className="mb-3 font-display text-[18px] font-semibold">{t.overview}</h2>
        <div className="grid grid-cols-3 gap-2">
          <OverviewStat
            color="hsl(var(--md-soft-green-deep))"
            bg="hsl(var(--md-soft-green)/0.35)"
            label={t.status.taken}
            value={taken.length}
            testid="stat-taken"
          />
          <OverviewStat
            color="hsl(var(--md-orange-dark))"
            bg="hsl(var(--md-orange)/0.18)"
            label={t.status.pending}
            value={pending.length}
            testid="stat-pending"
          />
          <OverviewStat
            color="hsl(var(--destructive))"
            bg="hsl(var(--destructive)/0.12)"
            label={t.status.missed}
            value={missed.length}
            testid="stat-missed"
          />
        </div>
      </section>

      {pending.length > 0 && (
        <section data-testid="section-pending-doses">
          <h3 className="mb-2 flex items-center gap-1.5 font-display text-[15px] font-semibold">
            <CalendarClock className="h-4 w-4 text-[hsl(var(--md-orange))]" /> {t.pendingCount(pending.length)}
          </h3>
          <ul className="flex flex-col gap-2">
            {pending.map((d) => (
              <li
                key={d.key}
                className="flex items-center gap-3 rounded-[16px] border border-[hsl(var(--md-border))] bg-[hsl(var(--md-cream-card))] p-3"
                data-testid={`row-pending-${d.medication.id}-${d.slot}`}
              >
                <PillIcon tone={pillToneForSlot(d.slot)} />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-display text-[15px] font-semibold">{d.medication.name}</p>
                  <p className="mt-0.5 text-[12px] text-[hsl(var(--md-muted))]">
                    {d.medication.dosage} · {t.times[d.slot]} · {medicationTimeForSlot(d.medication, d.slot)}
                  </p>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="rounded-full border-[hsl(var(--md-teal)/0.4)] text-[hsl(var(--md-teal-dark))]"
                  onClick={() => onSendReminder(d)}
                  data-testid={`button-overview-remind-${d.medication.id}-${d.slot}`}
                >
                  <Bell className="mr-1 h-3.5 w-3.5" /> {t.simulateReminder}
                </Button>
              </li>
            ))}
          </ul>
        </section>
      )}

      <section data-testid="section-meds-managed">
        <h3 className="mb-2 flex items-center gap-1.5 font-display text-[15px] font-semibold">
          <ShieldCheck className="h-4 w-4 text-[hsl(var(--md-teal))]" /> {t.myMeds} · {meds.length}
        </h3>
        <ul className="flex flex-col gap-2">
          {meds.map((m) => (
            <li
              key={m.id}
              className="flex items-center gap-3 rounded-[16px] border border-[hsl(var(--md-border))] bg-[hsl(var(--md-cream-card))] p-3"
              data-testid={`row-managed-${m.id}`}
            >
              <PillIcon tone={pillToneForSlot(m.schedule[0] ?? "morning")} />
              <div className="min-w-0 flex-1">
                <p className="truncate font-display text-[15px] font-semibold">{m.name}</p>
                <p className="mt-0.5 truncate text-[12px] text-[hsl(var(--md-muted))]">
                  {m.dosage} · {m.schedule.map((s) => `${t.times[s]} ${medicationTimeForSlot(m, s)}`).join(", ")}
                </p>
              </div>
              <ChevronRight className="h-4 w-4 text-[hsl(var(--md-muted))]" />
            </li>
          ))}
        </ul>
      </section>

      {logs.length > 0 && (
        <section data-testid="section-recent-activity">
          <h3 className="mb-2 flex items-center gap-1.5 font-display text-[15px] font-semibold">
            <Activity className="h-4 w-4 text-[hsl(var(--md-soft-green-deep))]" /> {t.recentActivity}
          </h3>
          <LogTab logs={logs.slice(-5)} t={t} />
        </section>
      )}
    </div>
  );
}

function OverviewStat({
  color,
  bg,
  label,
  value,
  testid,
}: {
  color: string;
  bg: string;
  label: string;
  value: number;
  testid: string;
}) {
  return (
    <div className="rounded-[14px] p-3 text-center" style={{ backgroundColor: bg }} data-testid={testid}>
      <div className="font-display text-[22px] font-semibold" style={{ color }}>
        {value}
      </div>
      <div className="mt-0.5 text-[11px] font-semibold uppercase tracking-wider" style={{ color }}>
        {label}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------
   Add medication dialog
   ------------------------------------------------------------------ */
function AddMedicationDialog({
  open,
  onOpenChange,
  t,
  onSubmit,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  t: typeof translations.en;
  onSubmit: (input: { name: string; dosage: string; schedule: TimeSlot[]; times: Record<string, string>; notes?: string }) => boolean;
}) {
  const [name, setName] = useState("");
  const [dosage, setDosage] = useState("");
  const [schedule, setSchedule] = useState<TimeSlot[]>(["morning"]);
  const [times, setTimes] = useState<Record<TimeSlot, string>>({ ...defaultTimeForSlot });
  const [notes, setNotes] = useState("");
  const [errors, setErrors] = useState<{ name?: string; dosage?: string; schedule?: string }>({});

  // Reset form when dialog opens
  useEffect(() => {
    if (open) {
      setName("");
      setDosage("");
      setSchedule(["morning"]);
      setTimes({ ...defaultTimeForSlot });
      setNotes("");
      setErrors({});
    }
  }, [open]);

  const toggleSlot = (s: TimeSlot) => {
    setSchedule((prev) =>
      prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s].sort((a, b) => TIME_SLOTS.indexOf(a) - TIME_SLOTS.indexOf(b))
    );
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const next: typeof errors = {};
    if (!name.trim()) next.name = "Required";
    if (!dosage.trim()) next.dosage = "Required";
    if (schedule.length === 0) next.schedule = "Pick at least one";
    setErrors(next);
    if (Object.keys(next).length > 0) return;
    const selectedTimes = Object.fromEntries(schedule.map((s) => [s, times[s]]));
    onSubmit({ name: name.trim(), dosage: dosage.trim(), schedule, times: selectedTimes, notes: notes.trim() || undefined });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="max-w-[440px] gap-0 overflow-hidden rounded-[22px] border-[hsl(var(--md-border))] bg-[hsl(var(--md-cream-card))] p-0"
        data-testid="dialog-add-medication"
      >
        <form onSubmit={submit}>
          <DialogHeader className="space-y-1 border-b border-[hsl(var(--md-border))] bg-[hsl(var(--md-cream))] px-5 pb-4 pt-5 text-left">
            <DialogTitle className="font-display text-[20px] font-semibold" data-testid="title-add-medication">
              <span className="mr-2 inline-flex h-7 w-7 items-center justify-center rounded-full bg-[hsl(var(--md-teal))] text-white align-text-bottom">
                <Plus className="h-4 w-4" strokeWidth={3} />
              </span>
              {t.addMed}
            </DialogTitle>
            <DialogDescription className="text-[13px] text-[hsl(var(--md-muted))]">
              {t.addedByCarer}.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3 px-5 py-5">
            <div>
              <Label htmlFor="med-name" className="text-[13px] font-semibold">
                {t.medName}
              </Label>
              <Input
                id="med-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t.medNamePh}
                className="mt-1 h-11 rounded-xl border-[hsl(var(--md-border))] bg-white text-[15px]"
                data-testid="input-medication-name"
                autoComplete="off"
              />
              {errors.name && (
                <p className="mt-1 text-[12px] text-[hsl(var(--destructive))]">{errors.name}</p>
              )}
            </div>

            <div>
              <Label htmlFor="med-dosage" className="text-[13px] font-semibold">
                {t.dosage}
              </Label>
              <Input
                id="med-dosage"
                value={dosage}
                onChange={(e) => setDosage(e.target.value)}
                placeholder={t.dosagePh}
                className="mt-1 h-11 rounded-xl border-[hsl(var(--md-border))] bg-white text-[15px]"
                data-testid="input-medication-dosage"
                autoComplete="off"
              />
              {errors.dosage && (
                <p className="mt-1 text-[12px] text-[hsl(var(--destructive))]">{errors.dosage}</p>
              )}
            </div>

            <div>
              <Label className="text-[13px] font-semibold">{t.schedule}</Label>
              <p className="mt-0.5 text-[12px] text-[hsl(var(--md-muted))]">{t.scheduleHelp}</p>
              <div className="mt-2 grid grid-cols-2 gap-2">
                {TIME_SLOTS.map((s) => {
                  const active = schedule.includes(s);
                  return (
                    <button
                      type="button"
                      key={s}
                      onClick={() => toggleSlot(s)}
                      className={cn(
                        "flex items-center gap-2 rounded-xl border px-3 py-2.5 text-left text-[13px] font-semibold transition-all",
                        active
                          ? "border-transparent text-white shadow-sm"
                          : "border-[hsl(var(--md-border))] bg-white text-[hsl(var(--md-muted))] hover:bg-[hsl(var(--md-cream))]"
                      )}
                      style={active ? { backgroundColor: `hsl(${slotColorVar[s]})` } : undefined}
                      data-testid={`toggle-schedule-${s}`}
                      aria-pressed={active}
                    >
                      <span aria-hidden>{slotEmoji[s]}</span>
                      {t.times[s]}
                    </button>
                  );
                })}
              </div>
              {errors.schedule && (
                <p className="mt-1 text-[12px] text-[hsl(var(--destructive))]">{errors.schedule}</p>
              )}
              {schedule.length > 0 && (
                <div className="mt-3 space-y-2 rounded-[14px] bg-[hsl(var(--md-cream))] p-3">
                  <p className="text-[12px] font-semibold uppercase tracking-wider text-[hsl(var(--md-muted))]">
                    {t.exactTime}
                  </p>
                  {schedule.map((s) => (
                    <div key={s} className="flex items-center gap-3">
                      <Label
                        htmlFor={`time-${s}`}
                        className="flex min-w-0 flex-1 items-center gap-2 text-[13px] font-semibold"
                      >
                        <span aria-hidden>{slotEmoji[s]}</span>
                        {t.times[s]}
                      </Label>
                      <Input
                        id={`time-${s}`}
                        type="time"
                        value={times[s]}
                        onChange={(e) => setTimes((prev) => ({ ...prev, [s]: e.target.value || defaultTimeForSlot[s] }))}
                        className="h-10 w-[118px] rounded-xl border-[hsl(var(--md-border))] bg-white text-[14px] font-semibold"
                        data-testid={`input-time-${s}`}
                        aria-label={`${t.time} ${t.times[s]}`}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div>
              <Label htmlFor="med-notes" className="text-[13px] font-semibold">
                {t.notes}
              </Label>
              <Textarea
                id="med-notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder={t.notesPh}
                className="mt-1 min-h-[68px] rounded-xl border-[hsl(var(--md-border))] bg-white text-[14px]"
                data-testid="input-medication-notes"
              />
            </div>
          </div>

          <div className="flex gap-2 border-t border-[hsl(var(--md-border))] bg-[hsl(var(--md-cream))] px-5 py-4">
            <Button
              type="button"
              variant="ghost"
              onClick={() => onOpenChange(false)}
              className="flex-1 rounded-xl"
              data-testid="button-cancel-add-medication"
            >
              {t.cancel}
            </Button>
            <Button
              type="submit"
              className="flex-[2] rounded-xl bg-[hsl(var(--md-teal))] font-display text-[15px] font-semibold hover:bg-[hsl(var(--md-teal-dark))]"
              data-testid="button-save-medication"
            >
              {t.save}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
