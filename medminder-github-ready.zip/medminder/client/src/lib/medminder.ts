import type { Medication, DoseLog, TimeSlot, DoseStatus } from "@shared/schema";
import { TIME_SLOTS } from "@shared/schema";

export type Role = "patient" | "carer";

export type Lang = "en" | "pt";

export type Strings = {
  appName: string;
  tagline: string;
  carer: string;
  patient: string;
  myMeds: string;
  log: string;
  overview: string;
  addMed: string;
  noMeds: string;
  noMedsHintPatient: string;
  noMedsHintCarer: string;
  take: string;
  taken: string;
  missed: string;
  pending: string;
  due: string;
  markTaken: string;
  markedTaken: string;
  removed: string;
  notify: string;
  logTitle: string;
  noLog: string;
  takenAt: string;
  cancel: string;
  save: string;
  medName: string;
  medNamePh: string;
  dosage: string;
  dosagePh: string;
  schedule: string;
  notes: string;
  notesPh: string;
  times: Record<TimeSlot, string>;
  status: Record<DoseStatus, string>;
  todaysProgress: string;
  takenCount: (a: number, b: number) => string;
  pendingCount: (n: number) => string;
  missedCount: (n: number) => string;
  adherence: string;
  recentActivity: string;
  reminderTitle: (name: string) => string;
  reminderBody: (dose: string, slot: string) => string;
  takenNotice: (name: string) => string;
  missedNotice: (name: string, slot: string) => string;
  addedNotice: (name: string) => string;
  simulateReminder: string;
  asPatient: string;
  asCarer: string;
  roleHint: string;
  brand: string;
  daily: string;
  patientSubtitle: string;
  carerSubtitle: string;
  removeConfirm: string;
  addedByCarer: string;
  scheduleHelp: string;
  remove: string;
  doseFor: string;
  language: string;
  loginTitle: string;
  loginSubtitle: string;
  email: string;
  password: string;
  signIn: string;
  signOut: string;
  demoPatient: string;
  demoCarer: string;
  createAccount: string;
  fullName: string;
  careCircle: string;
  accountType: string;
  linkAccounts: string;
  linkCode: string;
  enterLinkCode: string;
  linkAccount: string;
  linkedAccounts: string;
  linkedAs: string;
  shareCode: string;
  loginError: string;
  accountCreated: (name: string) => string;
  linkedNotice: (name: string) => string;
  alreadyLinked: string;
  codeNotFound: string;
  exactTime: string;
  time: string;
};

export const translations: Record<Lang, Strings> = {
  en: {
    appName: "Medminder",
    tagline: "Your caring medication companion",
    carer: "Carer",
    patient: "Patient",
    myMeds: "Medications",
    log: "Daily log",
    overview: "Overview",
    addMed: "Add medication",
    noMeds: "No medications yet",
    noMedsHintPatient: "Your carer will add medications here.",
    noMedsHintCarer: "Tap “Add medication” to set up the first dose.",
    take: "Take now",
    taken: "Taken",
    missed: "Missed",
    pending: "Pending",
    due: "Due",
    markTaken: "Mark as taken",
    markedTaken: "Marked as taken",
    removed: "Removed",
    notify: "Notify carer",
    logTitle: "Today’s log",
    noLog: "No activity yet today.",
    takenAt: "Taken at",
    cancel: "Cancel",
    save: "Save medication",
    medName: "Medication name",
    medNamePh: "e.g. Vitamin D",
    dosage: "Dosage",
    dosagePh: "e.g. 1 tablet",
    schedule: "Schedule",
    notes: "Notes (optional)",
    notesPh: "Take with food, etc.",
    times: { morning: "Morning", afternoon: "Afternoon", evening: "Evening", night: "Night" },
    status: { pending: "Pending", taken: "Taken", missed: "Missed" },
    todaysProgress: "Today’s progress",
    takenCount: (a, b) => `${a} of ${b} taken`,
    pendingCount: (n) => `${n} pending`,
    missedCount: (n) => `${n} missed`,
    adherence: "Adherence",
    recentActivity: "Recent activity",
    reminderTitle: (name) => `Time for ${name}`,
    reminderBody: (dose, slot) => `${dose} · ${slot} dose due now`,
    takenNotice: (name) => `${name} marked as taken`,
    missedNotice: (name, slot) => `${name} (${slot}) marked as missed`,
    addedNotice: (name) => `${name} added to schedule`,
    simulateReminder: "Send reminder",
    asPatient: "Patient view",
    asCarer: "Carer view",
    roleHint: "Switch roles to preview both sides of the prototype.",
    brand: "Medminder",
    daily: "Daily",
    patientSubtitle: "Stay on top of your medicines, one tap at a time.",
    carerSubtitle: "Monitor adherence and manage the medication plan.",
    removeConfirm: "Remove this medication?",
    addedByCarer: "Added by carer",
    scheduleHelp: "Pick the times this dose is taken each day.",
    remove: "Remove",
    doseFor: "Dose for",
    language: "PT",
    loginTitle: "Login to Medminder",
    loginSubtitle: "Patients and carers use separate logins, then link with a care-circle code.",
    email: "Email",
    password: "Password",
    signIn: "Sign in",
    signOut: "Sign out",
    demoPatient: "Demo patient",
    demoCarer: "Demo carer",
    createAccount: "Create account",
    fullName: "Full name",
    careCircle: "Care circle",
    accountType: "Account type",
    linkAccounts: "Link patient and carer",
    linkCode: "Link code",
    enterLinkCode: "Enter the other person's code",
    linkAccount: "Link account",
    linkedAccounts: "Linked accounts",
    linkedAs: "Signed in as",
    shareCode: "Share this code with your patient or carer.",
    loginError: "Check the email and password, then try again.",
    accountCreated: (name) => `Account created for ${name}`,
    linkedNotice: (name) => `Linked with ${name}`,
    alreadyLinked: "These accounts are already linked.",
    codeNotFound: "No account found with that code.",
    exactTime: "Exact time",
    time: "Time",
  },
  pt: {
    appName: "Medminder",
    tagline: "O seu companheiro de medicação",
    carer: "Cuidador",
    patient: "Paciente",
    myMeds: "Medicamentos",
    log: "Registo diário",
    overview: "Resumo",
    addMed: "Adicionar medicamento",
    noMeds: "Sem medicamentos",
    noMedsHintPatient: "O seu cuidador irá adicionar medicamentos aqui.",
    noMedsHintCarer: "Toque em “Adicionar medicamento” para começar.",
    take: "Tomar agora",
    taken: "Tomado",
    missed: "Falhado",
    pending: "Pendente",
    due: "A tomar",
    markTaken: "Marcar como tomado",
    markedTaken: "Marcado como tomado",
    removed: "Removido",
    notify: "Notificar cuidador",
    logTitle: "Registo de hoje",
    noLog: "Sem atividade hoje.",
    takenAt: "Tomado às",
    cancel: "Cancelar",
    save: "Guardar medicamento",
    medName: "Nome do medicamento",
    medNamePh: "ex. Vitamina D",
    dosage: "Dosagem",
    dosagePh: "ex. 1 comprimido",
    schedule: "Horário",
    notes: "Notas (opcional)",
    notesPh: "Tomar com comida, etc.",
    times: { morning: "Manhã", afternoon: "Tarde", evening: "Noite", night: "Madrugada" },
    status: { pending: "Pendente", taken: "Tomado", missed: "Falhado" },
    todaysProgress: "Progresso de hoje",
    takenCount: (a, b) => `${a} de ${b} tomados`,
    pendingCount: (n) => `${n} pendentes`,
    missedCount: (n) => `${n} falhados`,
    adherence: "Adesão",
    recentActivity: "Atividade recente",
    reminderTitle: (name) => `Hora de tomar ${name}`,
    reminderBody: (dose, slot) => `${dose} · dose da ${slot} agora`,
    takenNotice: (name) => `${name} marcado como tomado`,
    missedNotice: (name, slot) => `${name} (${slot}) marcado como falhado`,
    addedNotice: (name) => `${name} adicionado ao plano`,
    simulateReminder: "Enviar lembrete",
    asPatient: "Vista paciente",
    asCarer: "Vista cuidador",
    roleHint: "Troque de papel para ver ambos os lados do protótipo.",
    brand: "Medminder",
    daily: "Diário",
    patientSubtitle: "Os seus medicamentos, sempre à mão, num só toque.",
    carerSubtitle: "Acompanhe a adesão e gira o plano de medicação.",
    removeConfirm: "Remover este medicamento?",
    addedByCarer: "Adicionado pelo cuidador",
    scheduleHelp: "Escolha as alturas em que esta dose é tomada por dia.",
    remove: "Remover",
    doseFor: "Dose de",
    language: "EN",
    loginTitle: "Entrar no Medminder",
    loginSubtitle: "Pacientes e cuidadores usam logins separados e ligam as contas com um código.",
    email: "Email",
    password: "Palavra-passe",
    signIn: "Entrar",
    signOut: "Sair",
    demoPatient: "Demo paciente",
    demoCarer: "Demo cuidador",
    createAccount: "Criar conta",
    fullName: "Nome completo",
    careCircle: "Círculo de cuidado",
    accountType: "Tipo de conta",
    linkAccounts: "Ligar paciente e cuidador",
    linkCode: "Código de ligação",
    enterLinkCode: "Introduza o código da outra pessoa",
    linkAccount: "Ligar conta",
    linkedAccounts: "Contas ligadas",
    linkedAs: "Sessão iniciada como",
    shareCode: "Partilhe este código com o paciente ou cuidador.",
    loginError: "Verifique o email e a palavra-passe e tente novamente.",
    accountCreated: (name) => `Conta criada para ${name}`,
    linkedNotice: (name) => `Ligado a ${name}`,
    alreadyLinked: "Estas contas já estão ligadas.",
    codeNotFound: "Nenhuma conta encontrada com esse código.",
    exactTime: "Hora exata",
    time: "Hora",
  },
};

export const slotEmoji: Record<TimeSlot, string> = {
  morning: "🌅",
  afternoon: "☀️",
  evening: "🌇",
  night: "🌙",
};

export const slotHour: Record<TimeSlot, number> = {
  morning: 8,
  afternoon: 13,
  evening: 19,
  night: 22,
};

export const defaultTimeForSlot: Record<TimeSlot, string> = {
  morning: "08:00",
  afternoon: "13:00",
  evening: "19:00",
  night: "22:00",
};

export function medicationTimeForSlot(med: Medication, slot: TimeSlot): string {
  const value = med.times?.[slot];
  return typeof value === "string" && /^\d{2}:\d{2}$/.test(value) ? value : defaultTimeForSlot[slot];
}

export const slotColorVar: Record<TimeSlot, string> = {
  morning: "var(--md-morning)",
  afternoon: "var(--md-afternoon)",
  evening: "var(--md-evening)",
  night: "var(--md-night)",
};

export function isoToday(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export function formatClock(iso: string): string {
  const d = new Date(iso);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

export function scheduleKey(medId: string, slot: TimeSlot, day: string): string {
  return `${day}__${medId}__${slot}`;
}

export type DueDose = {
  key: string;
  medication: Medication;
  slot: TimeSlot;
  scheduledFor: string;
  status: DoseStatus;
  takenAt?: string;
  logId?: string;
};

export function buildTodaysDoses(
  meds: Medication[],
  logs: DoseLog[],
  day: string = isoToday()
): DueDose[] {
  const logByKey = new Map<string, DoseLog>();
  for (const log of logs) {
    logByKey.set(scheduleKey(log.medicationId, log.slot, day), log);
  }
  const out: DueDose[] = [];
  for (const med of meds) {
    for (const slot of med.schedule) {
      const k = scheduleKey(med.id, slot, day);
      const log = logByKey.get(k);
      const scheduled = new Date();
      const [hour, minute] = medicationTimeForSlot(med, slot).split(":").map(Number);
      scheduled.setHours(hour ?? slotHour[slot], minute ?? 0, 0, 0);
      out.push({
        key: k,
        medication: med,
        slot,
        scheduledFor: scheduled.toISOString(),
        status: log?.status ?? "pending",
        takenAt: log?.takenAt,
        logId: log?.id,
      });
    }
  }
  // Sort by schedule slot order
  out.sort(
    (a, b) =>
      TIME_SLOTS.indexOf(a.slot) - TIME_SLOTS.indexOf(b.slot) ||
      a.medication.name.localeCompare(b.medication.name)
  );
  return out;
}

export function newId(): string {
  // Math.random + timestamp is enough for prototype uniqueness
  return `${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export { TIME_SLOTS };
